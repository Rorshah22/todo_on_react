import Main from './Main';

export default Main;
